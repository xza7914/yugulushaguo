#ifndef __MACRO_H__
#define __MACRO_H__

const double INIT_PRIORITY = 2970.2978319553326;
const double PRODUCT_ID = 100;
const double LEVEL = 346.95775877784627;
const double URGENCY = 1074.0858049658912;
const double NINE_WORKSHOP = 1302.6704773921906;
const double COLLIDE = 3000;

#endif
