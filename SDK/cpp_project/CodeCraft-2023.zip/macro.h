#ifndef __MACRO_H__
#define __MACRO_H__

const double INIT_PRIORITY = 850;
const double PRODUCT_ID = 200;
const double LEVEL_1 = 200;
const double LEVEL_2 = 200;
const double URGENCY = 200;
const double NINE_WORKSHOP = 600;

#endif
