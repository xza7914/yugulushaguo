#ifndef __MACRO_H__
#define __MACRO_H__

const double INIT_PRIORITY = 2800;
const double PRODUCT_ID = 100;
const double LEVEL = 346.95775877784627;
const double URGENCY = 1100;
const double NINE_WORKSHOP = 700;
const double COLLIDE = 3700;

#endif
